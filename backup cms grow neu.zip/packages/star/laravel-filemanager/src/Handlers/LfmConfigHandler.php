<?php

namespace App\Handlers;

class LfmConfigHandler extends \Star\LaravelFilemanager\Handlers\ConfigHandler
{
    public function userField()
    {
        return parent::userField();
    }
}
