<?php

namespace Star\DataTables\Exceptions;

class Exception extends \Exception
{
}
