<?php

return [
    'name' => 'Website',
];
