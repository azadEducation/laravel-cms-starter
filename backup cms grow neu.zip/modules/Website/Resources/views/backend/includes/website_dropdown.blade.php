<ul class="dropdown-menu">
    <li>
        <a class="dropdown-item" href="{{ route('backend.websites.switch', 3) }}">
            <i class="fa-regular fa-user me-2"></i> Laravel Schema
        </a>
    </li>
    <li>
        <a class="dropdown-item" href="{{ route('backend.websites.switch', 2) }}">
            <i class="fa-regular fa-user me-2"></i> Azad Education
        </a>
    </li>
    <li>
        <a class="dropdown-item" href="{{ route('backend.websites.switch', 4) }}">
            <i class="fa-regular fa-user me-2"></i> Grow Neu
        </a>
    </li>
</ul>
