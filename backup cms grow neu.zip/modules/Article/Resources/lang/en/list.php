<?php

return [

    'id' => 'ID',
    'name' => 'Name',
    'category' => 'Category',
    'status' => 'Status',
    'action' => 'Action',

];
