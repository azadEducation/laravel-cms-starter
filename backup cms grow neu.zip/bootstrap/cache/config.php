<?php return array (
  'activitylog' => 
  array (
    'enabled' => true,
    'delete_records_older_than_days' => 365,
    'default_log_name' => 'default',
    'default_auth_driver' => NULL,
    'subject_returns_soft_deleted_models' => false,
    'activity_model' => 'Spatie\\Activitylog\\Models\\Activity',
    'table_name' => 'activity_log',
    'database_connection' => NULL,
  ),
  'app' => 
  array (
    'name' => 'Laravel Starter',
    'env' => 'local',
    'debug' => false,
    'url' => 'https://cms.azadeducation.in/',
    'asset_url' => NULL,
    'timezone' => 'Asia/Shanghai',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'available_locales' => 
    array (
      'en' => 'English (EN)',
    ),
    'initial_username' => '100000',
    'key' => 'base64:v/1vziVQZHHh9RflUzXfMPtcERG74XVFF4yUsSaRgOg=',
    'cipher' => 'AES-256-CBC',
    'salt' => 'zXfMPtcERG7XVFF4yUsSaRgOg',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'Menu' => 'Star\\Menu\\Facade',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'backup' => 
  array (
    'backup' => 
    array (
      'name' => 'Laravel Starter',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => '/home/u981434649/domains/growneu.com/public_html/cms',
          ),
          'exclude' => 
          array (
            0 => '/home/u981434649/domains/growneu.com/public_html/cms/.git',
            1 => '/home/u981434649/domains/growneu.com/public_html/cms/vendor',
            2 => '/home/u981434649/domains/growneu.com/public_html/cms/node_modules',
          ),
          'follow_links' => false,
          'ignore_unreadable_directories' => false,
          'relative_path' => NULL,
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'database_dump_compressor' => NULL,
      'database_dump_file_extension' => '',
      'destination' => 
      array (
        'filename_prefix' => '',
        'disks' => 
        array (
          0 => 'local',
        ),
      ),
      'temporary_directory' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app/backup-temp',
      'password' => NULL,
      'encryption' => 'default',
    ),
    'notifications' => 
    array (
      'notifications' => 
      array (
        'Spatie\\Backup\\Notifications\\Notifications\\BackupHasFailedNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\UnhealthyBackupWasFoundNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupHasFailedNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\BackupWasSuccessfulNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\HealthyBackupWasFoundNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupWasSuccessfulNotification' => 
        array (
          0 => 'mail',
        ),
      ),
      'notifiable' => 'Spatie\\Backup\\Notifications\\Notifiable',
      'mail' => 
      array (
        'to' => 'your@example.com',
        'from' => 
        array (
          'address' => 'hello@example.com',
          'name' => 'Laravel Starter',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => '',
        'channel' => NULL,
        'username' => NULL,
        'icon' => NULL,
      ),
      'discord' => 
      array (
        'webhook_url' => '',
        'username' => '',
        'avatar_url' => '',
      ),
    ),
    'monitor_backups' => 
    array (
      0 => 
      array (
        'name' => 'Laravel Starter',
        'disks' => 
        array (
          0 => 'local',
        ),
        'health_checks' => 
        array (
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumAgeInDays' => 1,
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumStorageInMegabytes' => 5000,
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'default_strategy' => 
      array (
        'keep_all_backups_for_days' => 7,
        'keep_daily_backups_for_days' => 16,
        'keep_weekly_backups_for_weeks' => 8,
        'keep_monthly_backups_for_months' => 4,
        'keep_yearly_backups_for_years' => 2,
        'delete_oldest_backups_when_using_more_megabytes_than' => 5000,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => '',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'laravel_starter_cache_',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'u981434649_blog',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u981434649_blog',
        'username' => 'u981434649_blog',
        'password' => 'Azad@blog@8386',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u981434649_blog',
        'username' => 'u981434649_blog',
        'password' => 'Azad@blog@8386',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u981434649_blog',
        'username' => 'u981434649_blog',
        'password' => 'Azad@blog@8386',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_starter_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => 'redis',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => 'redis',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
      'starts_with' => false,
    ),
    'index_column' => 'DT_RowIndex',
    'engines' => 
    array (
      'eloquent' => 'Star\\DataTables\\EloquentDataTable',
      'query' => 'Star\\DataTables\\QueryDataTable',
      'collection' => 'Star\\DataTables\\CollectionDataTable',
      'resource' => 'Star\\DataTables\\ApiResourceDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
    'callback' => 
    array (
      0 => '$',
      1 => '$.',
      2 => 'function',
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/debugbar',
      'connection' => NULL,
      'provider' => '',
      'hostname' => '127.0.0.1',
      'port' => 2304,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
      'livewire' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'backtrace_exclude_paths' => 
        array (
        ),
        'timeline' => false,
        'duration_background' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => false,
        'show_copy' => false,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'timeline' => false,
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'file-manager' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'Star\\LaravelFilemanager\\Handlers\\ConfigHandler',
    'allow_shared_folder' => true,
    'shared_folder_name' => 'shares',
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => 'files',
        'startup_view' => 'list',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'application/pdf',
          5 => 'text/plain',
        ),
      ),
      'image' => 
      array (
        'folder_name' => 'photos',
        'startup_view' => 'grid',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'disk' => 'public-file-manager',
    'rename_file' => true,
    'rename_duplicates' => true,
    'alphanumeric_filename' => true,
    'alphanumeric_directory' => true,
    'should_validate_size' => true,
    'should_validate_mime' => true,
    'over_write_on_duplicate' => false,
    'disallowed_mimetypes' => 
    array (
      0 => 'text/x-php',
      1 => 'text/html',
      2 => 'text/plain',
    ),
    'item_columns' => 
    array (
      0 => 'name',
      1 => 'url',
      2 => 'time',
      3 => 'icon',
      4 => 'is_file',
      5 => 'is_image',
      6 => 'thumb_url',
    ),
    'should_create_thumbnails' => true,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app/public',
        'url' => 'https://cms.azadeducation.in//storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      'public-file-manager' => 
      array (
        'driver' => 'local',
        'root' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app/public',
        'url' => '/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => '',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
      'media' => 
      array (
        'driver' => 'local',
        'root' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app/public/media',
        'url' => '/storage/media',
        'visibility' => 'public',
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      '/home/u981434649/domains/growneu.com/public_html/cms/public/storage' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'insights' => 
  array (
    'preset' => 'laravel',
    'ide' => NULL,
    'exclude' => 
    array (
    ),
    'add' => 
    array (
      'NunoMaduro\\PhpInsights\\Domain\\Metrics\\Architecture\\Classes' => 
      array (
        0 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenFinalClasses',
      ),
    ),
    'remove' => 
    array (
      0 => 'SlevomatCodingStandard\\Sniffs\\Namespaces\\AlphabeticallySortedUsesSniff',
      1 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\DeclareStrictTypesSniff',
      2 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\DisallowMixedTypeHintSniff',
      3 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenDefineFunctions',
      4 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenNormalClasses',
      5 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenTraits',
      6 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\ParameterTypeHintSniff',
      7 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\PropertyTypeHintSniff',
      8 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\ReturnTypeHintSniff',
      9 => 'SlevomatCodingStandard\\Sniffs\\Commenting\\UselessFunctionDocCommentSniff',
    ),
    'config' => 
    array (
      'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenPrivateMethods' => 
      array (
        'title' => 'The usage of private methods is not idiomatic in Laravel.',
      ),
    ),
    'requirements' => 
    array (
    ),
    'threads' => NULL,
    'timeout' => 60,
  ),
  'installer' => 
  array (
    'core' => 
    array (
      'minPhpVersion' => '8.0.0',
    ),
    'final' => 
    array (
      'key' => true,
      'publish' => false,
    ),
    'requirements' => 
    array (
      'php' => 
      array (
        0 => 'openssl',
        1 => 'pdo',
        2 => 'mbstring',
        3 => 'tokenizer',
        4 => 'JSON',
        5 => 'cURL',
      ),
      'apache' => 
      array (
        0 => 'mod_rewrite',
      ),
    ),
    'permissions' => 
    array (
      'storage/framework/' => '775',
      'storage/logs/' => '775',
      'bootstrap/cache/' => '775',
      '.env' => '775',
    ),
    'environment' => 
    array (
      'form' => 
      array (
        'rules' => 
        array (
          'app_name' => 'required|string|max:50',
          'environment' => 'required|string|max:50',
          'environment_custom' => 'required_if:environment,other|max:50',
          'app_debug' => 'required|string',
          'app_log_level' => 'required|string|max:50',
          'app_url' => 'required|url',
          'database_connection' => 'required|string|max:50',
          'database_hostname' => 'required|string|max:50',
          'database_port' => 'required|numeric',
          'database_name' => 'required|string|max:50',
          'database_username' => 'required|string|max:50',
          'database_password' => 'nullable|string|max:50',
          'broadcast_driver' => 'required|string|max:50',
          'cache_driver' => 'required|string|max:50',
          'session_driver' => 'required|string|max:50',
          'queue_driver' => 'required|string|max:50',
          'redis_hostname' => 'required|string|max:50',
          'redis_password' => 'required|string|max:50',
          'redis_port' => 'required|numeric',
          'mail_driver' => 'required|string|max:50',
          'mail_host' => 'required|string|max:50',
          'mail_port' => 'required|string|max:50',
          'mail_username' => 'required|string|max:50',
          'mail_password' => 'required|string|max:50',
          'mail_encryption' => 'required|string|max:50',
          'pusher_app_id' => 'max:50',
          'pusher_app_key' => 'max:50',
          'pusher_app_secret' => 'max:50',
        ),
      ),
    ),
    'installed' => 
    array (
      'redirectOptions' => 
      array (
        'route' => 
        array (
          'name' => 'welcome',
          'data' => 
          array (
          ),
        ),
        'abort' => 
        array (
          'type' => '404',
        ),
        'dump' => 
        array (
          'data' => 'Dumping a not found message.',
        ),
      ),
    ),
    'installedAlreadyAction' => '',
    'updaterEnabled' => 'true',
  ),
  'laravel-menu' => 
  array (
    'settings' => 
    array (
      'default' => 
      array (
        'auto_activate' => true,
        'activate_parents' => true,
        'active_class' => 'active show',
        'restful' => false,
        'cascade_data' => true,
        'rest_base' => '',
        'active_element' => 'item',
        'data_toggle_attribute' => 'data-toggle',
      ),
    ),
    'views' => 
    array (
      'bootstrap-items' => 'laravel-menu::bootstrap-navbar-items',
    ),
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Livewire',
    'view_path' => '/home/u981434649/domains/growneu.com/public_html/cms/resources/views/livewire',
    'layout' => 'components.components.layouts.app',
    'lazy_placeholder' => NULL,
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => false,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
    ),
    'inject_morph_markers' => true,
    'pagination_theme' => 'tailwind',
  ),
  'log-viewer' => 
  array (
    'storage-path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/logs',
    'pattern' => 
    array (
      'prefix' => 'laravel-',
      'date' => '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]',
      'extension' => '.log',
    ),
    'locale' => 'auto',
    'theme' => 'laravel-starter',
    'route' => 
    array (
      'enabled' => true,
      'attributes' => 
      array (
        'prefix' => 'admin/log-viewer',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'permission:view_logs',
        ),
      ),
    ),
    'per-page' => 30,
    'download' => 
    array (
      'prefix' => 'laravel-',
      'extension' => 'log',
    ),
    'menu' => 
    array (
      'filter-route' => 'log-viewer::logs.filter',
      'icons-enabled' => true,
    ),
    'icons' => 
    array (
      'all' => 'fa fa-fw fa-list',
      'emergency' => 'fa fa-fw fa-bug',
      'alert' => 'fa fa-fw fa-bullhorn',
      'critical' => 'fa fa-fw fa-heartbeat',
      'error' => 'fa fa-fw fa-times-circle',
      'warning' => 'fa fa-fw fa-exclamation-triangle',
      'notice' => 'fa fa-fw fa-exclamation-circle',
      'info' => 'fa fa-fw fa-info-circle',
      'debug' => 'fa fa-fw fa-life-ring',
    ),
    'colors' => 
    array (
      'levels' => 
      array (
        'empty' => '#D1D1D1',
        'all' => '#8A8A8A',
        'emergency' => '#B71C1C',
        'alert' => '#D32F2F',
        'critical' => '#F44336',
        'error' => '#FF5722',
        'warning' => '#FF9100',
        'notice' => '#4CAF50',
        'info' => '#1976D2',
        'debug' => '#90CAF9',
      ),
    ),
    'highlight' => 
    array (
      0 => '^#\\d+',
      1 => '^Stack trace:',
    ),
  ),
  'logging' => 
  array (
    'default' => 'daily',
    'deprecations' => 'null',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'mailhog',
        'port' => '1025',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Laravel Starter',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/home/u981434649/domains/growneu.com/public_html/cms/resources/views/vendor/mail',
      ),
    ),
  ),
  'media-library' => 
  array (
    'disk_name' => 'media',
    'max_file_size' => 10485760,
    'queue_connection_name' => 'sync',
    'queue_name' => '',
    'queue_conversions_by_default' => true,
    'media_model' => 'Spatie\\MediaLibrary\\MediaCollections\\Models\\Media',
    'use_default_collection_serialization' => false,
    'temporary_upload_model' => 'Spatie\\MediaLibraryPro\\Models\\TemporaryUpload',
    'enable_temporary_uploads_session_affinity' => true,
    'generate_thumbnails_for_temporary_uploads' => true,
    'file_namer' => 'Spatie\\MediaLibrary\\Support\\FileNamer\\DefaultFileNamer',
    'path_generator' => 'Spatie\\MediaLibrary\\Support\\PathGenerator\\DefaultPathGenerator',
    'file_remover_class' => 'Spatie\\MediaLibrary\\Support\\FileRemover\\DefaultFileRemover',
    'custom_path_generators' => 
    array (
    ),
    'url_generator' => 'Spatie\\MediaLibrary\\Support\\UrlGenerator\\DefaultUrlGenerator',
    'moves_media_on_update' => false,
    'version_urls' => false,
    'image_optimizers' => 
    array (
      'Spatie\\ImageOptimizer\\Optimizers\\Jpegoptim' => 
      array (
        0 => '-m85',
        1 => '--force',
        2 => '--strip-all',
        3 => '--all-progressive',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Pngquant' => 
      array (
        0 => '--force',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Optipng' => 
      array (
        0 => '-i0',
        1 => '-o2',
        2 => '-quiet',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Svgo' => 
      array (
        0 => '--disable=cleanupIDs',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Gifsicle' => 
      array (
        0 => '-b',
        1 => '-O3',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Cwebp' => 
      array (
        0 => '-m 6',
        1 => '-pass 10',
        2 => '-mt',
        3 => '-q 90',
      ),
    ),
    'image_generators' => 
    array (
      0 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Image',
      1 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Webp',
      2 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Pdf',
      3 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Svg',
      4 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Video',
    ),
    'temporary_directory_path' => NULL,
    'image_driver' => 'gd',
    'ffmpeg_path' => '/usr/bin/ffmpeg',
    'ffprobe_path' => '/usr/bin/ffprobe',
    'jobs' => 
    array (
      'perform_conversions' => 'Spatie\\MediaLibrary\\Conversions\\Jobs\\PerformConversionsJob',
      'generate_responsive_images' => 'Spatie\\MediaLibrary\\ResponsiveImages\\Jobs\\GenerateResponsiveImagesJob',
    ),
    'media_downloader' => 'Spatie\\MediaLibrary\\Downloaders\\DefaultDownloader',
    'remote' => 
    array (
      'extra_headers' => 
      array (
        'CacheControl' => 'max-age=604800',
      ),
    ),
    'responsive_images' => 
    array (
      'width_calculator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\WidthCalculator\\FileSizeOptimizedWidthCalculator',
      'use_tiny_placeholders' => true,
      'tiny_placeholder_generator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\TinyPlaceholderGenerator\\Blurred',
    ),
    'enable_vapor_uploads' => false,
    'default_loading_attribute_value' => NULL,
    'prefix' => '',
  ),
  'module-manager' => 
  array (
    'namespace' => 'Modules',
    'stubs' => 
    array (
      'path' => '/home/u981434649/domains/growneu.com/public_html/cms/stubs/star-stubs',
    ),
    'module' => 
    array (
      'files' => 
      array (
        'composer' => 
        array (
          0 => 'composer.stub',
          1 => 'composer.json',
        ),
        'json' => 
        array (
          0 => 'module.stub',
          1 => 'module.json',
        ),
        'config' => 
        array (
          0 => 'Config/config.stub',
          1 => 'Config/config.php',
        ),
        'database' => 
        array (
          0 => 'Database/migrations/stubMigration.stub',
          1 => 'Database/migrations/stubMigration.php',
          2 => 'rename',
        ),
        'factories' => 
        array (
          0 => 'Database/factories/stubFactory.stub',
          1 => 'Database/factories/stubFactory.php',
          2 => 'rename',
        ),
        'seeders' => 
        array (
          0 => 'Database/seeders/stubSeeders.stub',
          1 => 'Database/seeders/stubSeeders.php',
          2 => 'rename',
        ),
        'command' => 
        array (
          0 => 'Console/Commands/StubCommand.stub',
          1 => 'Console/Commands/StubCommand.php',
          2 => 'rename',
        ),
        'lang' => 
        array (
          0 => 'lang/en/text.stub',
          1 => 'lang/en/text.php',
        ),
        'models' => 
        array (
          0 => 'Models/stubModel.stub',
          1 => 'Models/stubModel.php',
        ),
        'providersRoute' => 
        array (
          0 => 'Providers/RouteServiceProvider.stub',
          1 => 'Providers/RouteServiceProvider.php',
        ),
        'providersEvent' => 
        array (
          0 => 'Providers/EventServiceProvider.stub',
          1 => 'Providers/EventServiceProvider.php',
        ),
        'providers' => 
        array (
          0 => 'Providers/stubServiceProvider.stub',
          1 => 'Providers/stubServiceProvider.php',
        ),
        'route_web' => 
        array (
          0 => 'routes/web.stub',
          1 => 'routes/web.php',
        ),
        'route_api' => 
        array (
          0 => 'routes/api.stub',
          1 => 'routes/api.php',
        ),
        'controller_backend' => 
        array (
          0 => 'Http/Controllers/Backend/stubBackendController.stub',
          1 => 'Http/Controllers/Backend/stubBackendController.php',
        ),
        'controller_frontend' => 
        array (
          0 => 'Http/Controllers/Frontend/stubFrontendController.stub',
          1 => 'Http/Controllers/Frontend/stubFrontendController.php',
        ),
        'middleware_menu' => 
        array (
          0 => 'Http/Middleware/GenerateMenus.stub',
          1 => 'Http/Middleware/GenerateMenus.php',
        ),
        'views_backend_index' => 
        array (
          0 => 'Resources/views/backend/stubViews/index.blade.stub',
          1 => 'Resources/views/backend/stubViews/index.blade.php',
        ),
        'views_backend_index_datatable' => 
        array (
          0 => 'Resources/views/backend/stubViews/index_datatable.blade.stub',
          1 => 'Resources/views/backend/stubViews/index_datatable.blade.php',
        ),
        'views_backend_create' => 
        array (
          0 => 'Resources/views/backend/stubViews/create.blade.stub',
          1 => 'Resources/views/backend/stubViews/create.blade.php',
        ),
        'views_backend_form' => 
        array (
          0 => 'Resources/views/backend/stubViews/form.blade.stub',
          1 => 'Resources/views/backend/stubViews/form.blade.php',
        ),
        'views_backend_show' => 
        array (
          0 => 'Resources/views/backend/stubViews/show.blade.stub',
          1 => 'Resources/views/backend/stubViews/show.blade.php',
        ),
        'views_backend_edit' => 
        array (
          0 => 'Resources/views/backend/stubViews/edit.blade.stub',
          1 => 'Resources/views/backend/stubViews/edit.blade.php',
        ),
        'views_backend_trash' => 
        array (
          0 => 'Resources/views/backend/stubViews/trash.blade.stub',
          1 => 'Resources/views/backend/stubViews/trash.blade.php',
        ),
        'views_frontend_index' => 
        array (
          0 => 'Resources/views/frontend/stubViews/index.blade.stub',
          1 => 'Resources/views/frontend/stubViews/index.blade.php',
        ),
        'views_frontend_show' => 
        array (
          0 => 'Resources/views/frontend/stubViews/show.blade.stub',
          1 => 'Resources/views/frontend/stubViews/show.blade.php',
        ),
      ),
    ),
    'composer' => 
    array (
      'vendor' => 'star',
      'author' => 
      array (
        'name' => 'Star',
        'email' => 'star@local.dev',
      ),
    ),
  ),
  'modules' => 
  array (
    'namespace' => 'Modules',
    'stubs' => 
    array (
      'enabled' => true,
      'path' => '/home/u981434649/domains/growneu.com/public_html/cms/packages/star/laravel-modules/src/Commands/stubs',
      'files' => 
      array (
        'routes/web' => 'routes/web.php',
        'routes/api' => 'routes/api.php',
        'views/index' => 'Resources/views/index.blade.php',
        'views/master' => 'Resources/views/layouts/master.blade.php',
        'scaffold/config' => 'Config/config.php',
        'composer' => 'composer.json',
        'assets/js/app' => 'Resources/assets/js/app.js',
        'assets/css/app' => 'Resources/assets/css/app.scss',
        'package' => 'package.json',
      ),
      'replacements' => 
      array (
        'routes/web' => 
        array (
          0 => 'LOWER_NAME',
          1 => 'STUDLY_NAME',
        ),
        'routes/api' => 
        array (
          0 => 'LOWER_NAME',
        ),
        'webpack' => 
        array (
          0 => 'LOWER_NAME',
        ),
        'json' => 
        array (
          0 => 'LOWER_NAME',
          1 => 'STUDLY_NAME',
          2 => 'MODULE_NAMESPACE',
          3 => 'PROVIDER_NAMESPACE',
        ),
        'views/index' => 
        array (
          0 => 'LOWER_NAME',
        ),
        'views/master' => 
        array (
          0 => 'LOWER_NAME',
          1 => 'STUDLY_NAME',
        ),
        'scaffold/config' => 
        array (
          0 => 'STUDLY_NAME',
        ),
        'composer' => 
        array (
          0 => 'LOWER_NAME',
          1 => 'STUDLY_NAME',
          2 => 'VENDOR',
          3 => 'AUTHOR_NAME',
          4 => 'AUTHOR_EMAIL',
          5 => 'MODULE_NAMESPACE',
          6 => 'PROVIDER_NAMESPACE',
        ),
      ),
      'gitkeep' => true,
    ),
    'paths' => 
    array (
      'modules' => '/home/u981434649/domains/growneu.com/public_html/cms/modules',
      'assets' => '/home/u981434649/domains/growneu.com/public_html/cms/public/modules',
      'migration' => '/home/u981434649/domains/growneu.com/public_html/cms/Database/migrations',
      'generator' => 
      array (
        'config' => 
        array (
          'path' => 'Config',
          'generate' => true,
        ),
        'command' => 
        array (
          'path' => 'Console',
          'generate' => true,
        ),
        'migration' => 
        array (
          'path' => 'Database/Migrations',
          'generate' => true,
        ),
        'seeder' => 
        array (
          'path' => 'Database/Seeders',
          'generate' => true,
        ),
        'factory' => 
        array (
          'path' => 'Database/factories',
          'generate' => true,
        ),
        'model' => 
        array (
          'path' => 'Entities',
          'generate' => true,
        ),
        'routes' => 
        array (
          'path' => 'routes',
          'generate' => true,
        ),
        'controller' => 
        array (
          'path' => 'Http/Controllers',
          'generate' => true,
        ),
        'filter' => 
        array (
          'path' => 'Http/Middleware',
          'generate' => true,
        ),
        'request' => 
        array (
          'path' => 'Http/Requests',
          'generate' => true,
        ),
        'provider' => 
        array (
          'path' => 'Providers',
          'generate' => true,
        ),
        'assets' => 
        array (
          'path' => 'Resources/assets',
          'generate' => true,
        ),
        'lang' => 
        array (
          'path' => 'Resources/lang',
          'generate' => true,
        ),
        'views' => 
        array (
          'path' => 'Resources/views',
          'generate' => true,
        ),
        'test' => 
        array (
          'path' => 'Tests/Unit',
          'generate' => true,
        ),
        'test-feature' => 
        array (
          'path' => 'Tests/Feature',
          'generate' => true,
        ),
        'repository' => 
        array (
          'path' => 'Repositories',
          'generate' => false,
        ),
        'event' => 
        array (
          'path' => 'Events',
          'generate' => false,
        ),
        'listener' => 
        array (
          'path' => 'Listeners',
          'generate' => false,
        ),
        'policies' => 
        array (
          'path' => 'Policies',
          'generate' => false,
        ),
        'rules' => 
        array (
          'path' => 'Rules',
          'generate' => false,
        ),
        'jobs' => 
        array (
          'path' => 'Jobs',
          'generate' => false,
        ),
        'emails' => 
        array (
          'path' => 'Emails',
          'generate' => false,
        ),
        'notifications' => 
        array (
          'path' => 'Notifications',
          'generate' => false,
        ),
        'resource' => 
        array (
          'path' => 'Transformers',
          'generate' => false,
        ),
        'component-view' => 
        array (
          'path' => 'Resources/views/components',
          'generate' => false,
        ),
        'component-class' => 
        array (
          'path' => 'View/Components',
          'generate' => false,
        ),
      ),
    ),
    'commands' => 
    array (
      0 => 'Star\\Modules\\Commands\\CommandMakeCommand',
      1 => 'Star\\Modules\\Commands\\ComponentClassMakeCommand',
      2 => 'Star\\Modules\\Commands\\ComponentViewMakeCommand',
      3 => 'Star\\Modules\\Commands\\ControllerMakeCommand',
      4 => 'Star\\Modules\\Commands\\DisableCommand',
      5 => 'Star\\Modules\\Commands\\DumpCommand',
      6 => 'Star\\Modules\\Commands\\EnableCommand',
      7 => 'Star\\Modules\\Commands\\EventMakeCommand',
      8 => 'Star\\Modules\\Commands\\JobMakeCommand',
      9 => 'Star\\Modules\\Commands\\ListenerMakeCommand',
      10 => 'Star\\Modules\\Commands\\MailMakeCommand',
      11 => 'Star\\Modules\\Commands\\MiddlewareMakeCommand',
      12 => 'Star\\Modules\\Commands\\NotificationMakeCommand',
      13 => 'Star\\Modules\\Commands\\ProviderMakeCommand',
      14 => 'Star\\Modules\\Commands\\RouteProviderMakeCommand',
      15 => 'Star\\Modules\\Commands\\InstallCommand',
      16 => 'Star\\Modules\\Commands\\ListCommand',
      17 => 'Star\\Modules\\Commands\\ModuleDeleteCommand',
      18 => 'Star\\Modules\\Commands\\ModuleMakeCommand',
      19 => 'Star\\Modules\\Commands\\FactoryMakeCommand',
      20 => 'Star\\Modules\\Commands\\PolicyMakeCommand',
      21 => 'Star\\Modules\\Commands\\RequestMakeCommand',
      22 => 'Star\\Modules\\Commands\\RuleMakeCommand',
      23 => 'Star\\Modules\\Commands\\MigrateCommand',
      24 => 'Star\\Modules\\Commands\\MigrateRefreshCommand',
      25 => 'Star\\Modules\\Commands\\MigrateResetCommand',
      26 => 'Star\\Modules\\Commands\\MigrateRollbackCommand',
      27 => 'Star\\Modules\\Commands\\MigrateStatusCommand',
      28 => 'Star\\Modules\\Commands\\MigrationMakeCommand',
      29 => 'Star\\Modules\\Commands\\ModelMakeCommand',
      30 => 'Star\\Modules\\Commands\\PublishCommand',
      31 => 'Star\\Modules\\Commands\\PublishConfigurationCommand',
      32 => 'Star\\Modules\\Commands\\PublishMigrationCommand',
      33 => 'Star\\Modules\\Commands\\PublishTranslationCommand',
      34 => 'Star\\Modules\\Commands\\SeedCommand',
      35 => 'Star\\Modules\\Commands\\SeedMakeCommand',
      36 => 'Star\\Modules\\Commands\\SetupCommand',
      37 => 'Star\\Modules\\Commands\\UnUseCommand',
      38 => 'Star\\Modules\\Commands\\UpdateCommand',
      39 => 'Star\\Modules\\Commands\\UseCommand',
      40 => 'Star\\Modules\\Commands\\ResourceMakeCommand',
      41 => 'Star\\Modules\\Commands\\TestMakeCommand',
      42 => 'Star\\Modules\\Commands\\LaravelModulesV6Migrator',
    ),
    'scan' => 
    array (
      'enabled' => false,
      'paths' => 
      array (
        0 => '/home/u981434649/domains/growneu.com/public_html/cms/vendor/*/*',
        1 => '/home/u981434649/domains/growneu.com/public_html/cms/packages/*/*',
      ),
    ),
    'composer' => 
    array (
      'vendor' => 'star',
      'author' => 
      array (
        'name' => 'Star',
        'email' => 'star@locol.dev',
      ),
      'composer-output' => false,
    ),
    'cache' => 
    array (
      'enabled' => false,
      'key' => 'laravel-modules',
      'lifetime' => 60,
    ),
    'register' => 
    array (
      'translations' => true,
      'files' => 'register',
    ),
    'activators' => 
    array (
      'file' => 
      array (
        'class' => 'Star\\Modules\\Activators\\FileActivator',
        'statuses-file' => '/home/u981434649/domains/growneu.com/public_html/cms/modules_statuses.json',
        'cache-key' => 'activator.installed',
        'cache-lifetime' => 604800,
      ),
    ),
    'activator' => 'file',
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'teams' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => false,
    'cache' => 
    array (
      'expiration_time' => 
      \DateInterval::__set_state(array(
         'from_string' => true,
         'date_string' => '24 hours',
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => '',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'cms.azadeducation.in',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => '',
    ),
    'facebook' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'http://laravel-starter.local/login/facebook/callback',
    ),
    'github' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'http://laravel-starter.local/login/github/callback',
    ),
    'google' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'http://laravel-starter.local/login/google/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_starter_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'setting_fields' => 
  array (
    'app' => 
    array (
      'title' => 'General',
      'desc' => 'All the general settings for application.',
      'icon' => 'fas fa-cube',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'app_name',
          'label' => 'App Name',
          'rules' => 'required|min:2|max:50',
          'class' => '',
          'value' => 'Laravel CMS Starter',
        ),
        1 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'footer_text',
          'label' => 'Footer Text',
          'rules' => '',
          'class' => '',
          'value' => 'Built with ♥ from Laravel',
        ),
        2 => 
        array (
          'type' => 'checkbox',
          'data' => 'text',
          'name' => 'show_copyright',
          'label' => 'Show Copyright',
          'rules' => '',
          'class' => '',
          'value' => '1',
        ),
      ),
    ),
    'meta' => 
    array (
      'title' => 'Meta ',
      'desc' => 'Application Meta Data',
      'icon' => 'fa-solid fa-earth-asia',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_site_name',
          'label' => 'Meta Site Name',
          'rules' => '',
          'class' => '',
          'value' => 'Awesome Laravel | A Laravel Starter Project',
        ),
        1 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_description',
          'label' => 'Meta Description',
          'rules' => '',
          'class' => '',
          'value' => 'Meta Description',
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_keyword',
          'label' => 'Meta Keyword',
          'rules' => '',
          'class' => '',
          'value' => 'Web Application, web app, Laravel, Laravel starter, Bootstrap, Admin, Template, Open Source',
        ),
        3 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_image',
          'label' => 'Meta Image',
          'rules' => '',
          'class' => '',
          'value' => 'images/default.png',
        ),
        4 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_fb_app_id',
          'label' => 'Meta Facebook App Id',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        5 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_twitter_site',
          'label' => 'Meta Twitter Site Account',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        6 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'meta_twitter_creator',
          'label' => 'Meta Twitter Creator Account',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
      ),
    ),
    'email' => 
    array (
      'title' => 'Email',
      'desc' => 'Email settings for app',
      'icon' => 'fas fa-envelope',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'email',
          'data' => 'string',
          'name' => 'email',
          'label' => 'Email',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
      ),
    ),
    'analytics' => 
    array (
      'title' => 'Analytics',
      'desc' => 'Application Analytics',
      'icon' => 'fas fa-chart-line',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'text',
          'name' => 'google_analytics',
          'label' => 'Google Analytics',
          'rules' => '',
          'class' => '',
          'value' => '',
          'help' => 'Paste the only the Measurement Id of Google Analytics stream.',
        ),
      ),
    ),
    'custom_css' => 
    array (
      'title' => 'Custom Code',
      'desc' => 'Custom code area',
      'icon' => 'fa-solid fa-file-code',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'textarea',
          'data' => 'string',
          'name' => 'custom_css_block',
          'label' => 'Custom Css Code',
          'rules' => '',
          'class' => '',
          'value' => '',
          'help' => 'Paste the code in this field.',
          'display' => 'raw',
        ),
      ),
    ),
    'social' => 
    array (
      'title' => 'Social Profiles',
      'desc' => 'Link of all the online/social profiles.',
      'icon' => 'fas fa-users',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'website_url',
          'label' => 'Website URL',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        1 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'facebook_url',
          'label' => 'Facebook Page URL',
          'rules' => '',
          'class' => '',
          'value' => '#',
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'twitter_url',
          'label' => 'Twitter Profile URL',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        3 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'instagram_url',
          'label' => 'Instagram Account URL',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        4 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'youtube_url',
          'label' => 'Youtube Channel URL',
          'rules' => '',
          'class' => '',
          'value' => '',
        ),
        5 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'linkedin_url',
          'label' => 'LinkedIn URL',
          'rules' => '',
          'class' => '',
          'value' => '#',
        ),
        6 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'whatsapp_url',
          'label' => 'WhatsApp URL',
          'rules' => '',
          'class' => '',
          'value' => '#',
        ),
        7 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'messenger_url',
          'label' => 'Messenger URL',
          'rules' => '',
          'class' => '',
          'value' => '#',
        ),
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/u981434649/domains/growneu.com/public_html/cms/resources/views',
    ),
    'compiled' => '/home/u981434649/domains/growneu.com/public_html/cms/storage/framework/views',
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '/home/u981434649/domains/growneu.com/public_html/cms',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'lfm-config' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'Star\\LaravelFilemanager\\Handlers\\ConfigHandler',
    'allow_shared_folder' => true,
    'shared_folder_name' => 'shares',
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => 'files',
        'startup_view' => 'list',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'application/pdf',
          5 => 'text/plain',
        ),
      ),
      'image' => 
      array (
        'folder_name' => 'photos',
        'startup_view' => 'grid',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'disk' => 'public',
    'rename_file' => false,
    'rename_duplicates' => false,
    'alphanumeric_filename' => false,
    'alphanumeric_directory' => false,
    'should_validate_size' => false,
    'should_validate_mime' => true,
    'over_write_on_duplicate' => false,
    'disallowed_mimetypes' => 
    array (
      0 => 'text/x-php',
      1 => 'text/html',
      2 => 'text/plain',
    ),
    'disallowed_extensions' => 
    array (
      0 => 'php',
      1 => 'html',
    ),
    'item_columns' => 
    array (
      0 => 'name',
      1 => 'url',
      2 => 'time',
      3 => 'icon',
      4 => 'is_file',
      5 => 'is_image',
      6 => 'thumb_url',
    ),
    'should_create_thumbnails' => true,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'laravel-module-manager' => 
  array (
    'namespace' => 'Modules',
    'stubs' => 
    array (
      'path' => '/home/u981434649/domains/growneu.com/public_html/cms/stubs/star-stubs',
    ),
    'module' => 
    array (
      'files' => 
      array (
        'composer' => 
        array (
          0 => 'composer.stub',
          1 => 'composer.json',
        ),
        'json' => 
        array (
          0 => 'module.stub',
          1 => 'module.json',
        ),
        'config' => 
        array (
          0 => 'Config/config.stub',
          1 => 'Config/config.php',
        ),
        'database' => 
        array (
          0 => 'Database/migrations/stubMigration.stub',
          1 => 'Database/migrations/stubMigration.php',
          2 => 'rename',
        ),
        'factories' => 
        array (
          0 => 'Database/factories/stubFactory.stub',
          1 => 'Database/factories/stubFactory.php',
          2 => 'rename',
        ),
        'seeders' => 
        array (
          0 => 'Database/seeders/stubSeeders.stub',
          1 => 'Database/seeders/stubSeeders.php',
          2 => 'rename',
        ),
        'command' => 
        array (
          0 => 'Console/Commands/StubCommand.stub',
          1 => 'Console/Commands/StubCommand.php',
          2 => 'rename',
        ),
        'lang' => 
        array (
          0 => 'lang/en/text.stub',
          1 => 'lang/en/text.php',
        ),
        'models' => 
        array (
          0 => 'Models/stubModel.stub',
          1 => 'Models/stubModel.php',
        ),
        'providersRoute' => 
        array (
          0 => 'Providers/RouteServiceProvider.stub',
          1 => 'Providers/RouteServiceProvider.php',
        ),
        'providersEvent' => 
        array (
          0 => 'Providers/EventServiceProvider.stub',
          1 => 'Providers/EventServiceProvider.php',
        ),
        'providers' => 
        array (
          0 => 'Providers/stubServiceProvider.stub',
          1 => 'Providers/stubServiceProvider.php',
        ),
        'route_web' => 
        array (
          0 => 'routes/web.stub',
          1 => 'routes/web.php',
        ),
        'route_api' => 
        array (
          0 => 'routes/api.stub',
          1 => 'routes/api.php',
        ),
        'controller_backend' => 
        array (
          0 => 'Http/Controllers/Backend/stubBackendController.stub',
          1 => 'Http/Controllers/Backend/stubBackendController.php',
        ),
        'controller_frontend' => 
        array (
          0 => 'Http/Controllers/Frontend/stubFrontendController.stub',
          1 => 'Http/Controllers/Frontend/stubFrontendController.php',
        ),
        'middleware_menu' => 
        array (
          0 => 'Http/Middleware/GenerateMenus.stub',
          1 => 'Http/Middleware/GenerateMenus.php',
        ),
        'views_backend_index' => 
        array (
          0 => 'Resources/views/backend/stubViews/index.blade.stub',
          1 => 'Resources/views/backend/stubViews/index.blade.php',
        ),
        'views_backend_index_datatable' => 
        array (
          0 => 'Resources/views/backend/stubViews/index_datatable.blade.stub',
          1 => 'Resources/views/backend/stubViews/index_datatable.blade.php',
        ),
        'views_backend_create' => 
        array (
          0 => 'Resources/views/backend/stubViews/create.blade.stub',
          1 => 'Resources/views/backend/stubViews/create.blade.php',
        ),
        'views_backend_form' => 
        array (
          0 => 'Resources/views/backend/stubViews/form.blade.stub',
          1 => 'Resources/views/backend/stubViews/form.blade.php',
        ),
        'views_backend_show' => 
        array (
          0 => 'Resources/views/backend/stubViews/show.blade.stub',
          1 => 'Resources/views/backend/stubViews/show.blade.php',
        ),
        'views_backend_edit' => 
        array (
          0 => 'Resources/views/backend/stubViews/edit.blade.stub',
          1 => 'Resources/views/backend/stubViews/edit.blade.php',
        ),
        'views_backend_trash' => 
        array (
          0 => 'Resources/views/backend/stubViews/trash.blade.stub',
          1 => 'Resources/views/backend/stubViews/trash.blade.php',
        ),
        'views_frontend_index' => 
        array (
          0 => 'Resources/views/frontend/stubViews/index.blade.stub',
          1 => 'Resources/views/frontend/stubViews/index.blade.php',
        ),
        'views_frontend_show' => 
        array (
          0 => 'Resources/views/frontend/stubViews/show.blade.stub',
          1 => 'Resources/views/frontend/stubViews/show.blade.php',
        ),
      ),
    ),
    'composer' => 
    array (
      'vendor' => 'star',
      'author' => 
      array (
        'name' => 'Star',
        'email' => 'star@local.dev',
      ),
    ),
  ),
  'article' => 
  array (
    'name' => 'Article',
  ),
  'category' => 
  array (
    'name' => 'Category',
  ),
  'comment' => 
  array (
    'name' => 'Comment',
  ),
  'page' => 
  array (
    'name' => 'Page',
  ),
  'tag' => 
  array (
    'name' => 'Tag',
  ),
  'website' => 
  array (
    'name' => 'Website',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
